import express from "express";
import {
  addReview,
  deleteReview,
} from "../../backend/controllers/review.controller.js";
import { protect } from "../../backend/middleware/auth.middleware.js";

const router = express.Router();
router.post("/:productId", protect, addReview);
router.delete("/:productId/:reviewId", protect, deleteReview);
export default router;
