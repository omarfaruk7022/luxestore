import express from "express";
import {
  getWishlist,
  toggleWishlist,
} from "../../backend/controllers/user.controller.js";
import { protect } from "../../backend/middleware/auth.middleware.js";

const router = express.Router();
router.use(protect);
router.get("/wishlist", getWishlist);
router.post("/wishlist/:productId", toggleWishlist);
export default router;
