// category.routes.js
import express from "express";
import {
  getCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory,
} from "../../backend/controllers/category.controller.js";
import {
  protect,
  adminOnly,
} from "../../backend/middleware/auth.middleware.js";

const router = express.Router();
router.get("/categories", getCategories);
router.get("/categories/:slug", getCategory);
router.post("/categories", protect, adminOnly, createCategory);
router.put("/categories/:id", protect, adminOnly, updateCategory);
router.delete("/categories/:id", protect, adminOnly, deleteCategory);
export default router;
