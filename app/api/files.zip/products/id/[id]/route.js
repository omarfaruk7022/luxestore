import {
  updateProduct,
  deleteProduct,
} from "@/backend/controllers/product.controller.js";

import { protect, adminOnly } from "@/backend/middleware/auth.middleware.js";

export async function PUT(req, { params }) {
  await protect(req);
  await adminOnly(req);

  return updateProduct(req, params.id);
}

export async function DELETE(req, { params }) {
  await protect(req);
  await adminOnly(req);

  return deleteProduct(req, params.id);
}
