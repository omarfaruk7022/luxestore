import express from "express";
import {
  createOrder,
  getMyOrders,
  getOrder,
  cancelOrder,
} from "../../backend/controllers/order.controller.js";
import { protect } from "../../backend/middleware/auth.middleware.js";

const router = express.Router();
router.use(protect);
router.post("/", createOrder);
router.get("/", getMyOrders);
router.get("/:id", getOrder);
router.put("/:id/cancel", cancelOrder);
export default router;
