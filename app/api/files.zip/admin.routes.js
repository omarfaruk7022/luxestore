import express from "express";
import {
  getDashboardStats,
  getAllOrders,
  updateOrderStatus,
  getAllUsers,
  toggleUserStatus,
} from "../../backend/controllers/admin.controller.js";
import {
  protect,
  adminOnly,
} from "../../backend/middleware/auth.middleware.js";

const router = express.Router();
router.use(protect, adminOnly);
router.get("/stats", getDashboardStats);
router.get("/orders", getAllOrders);
router.put("/orders/:id/status", updateOrderStatus);
router.get("/users", getAllUsers);
router.put("/users/:id/toggle", toggleUserStatus);
export default router;
